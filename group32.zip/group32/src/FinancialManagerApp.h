/**
 * Author: Group 32
 * Date: November 7, 2023
 * Description: Header file to declare all public and private variables and functions for the Financial Manager app.
 * Description will be continued below.
 */

/**
 * Include statements ensure the header files necessary to building a Wt application are imported.
 */

#ifndef FINANCIALMANAGERAPP_H
#define FINANCIALMANAGERAPP_H

#include <Wt/WApplication.h>
#include <Wt/WContainerWidget.h>
#include <Wt/WLabel.h>
#include <Wt/WComboBox.h>
#include <Wt/WPushButton.h>
#include <Wt/WText.h>
#include <Wt/WLineEdit.h>
#include <Wt/WTable.h>

/*
 * A simple Financial Manager application class which demonstrates how to react
 * to events, read input, and give feedback.
 */

class FinancialManagerApp : public Wt::WApplication
{
public:
    FinancialManagerApp(const Wt::WEnvironment &env);

private:
    void setupApp();
    void setupAddIncomePage(Wt::WContainerWidget *parent);
    void setupCheckBalancePage(Wt::WContainerWidget *parent);
    void setupConvertCurrencyPage(Wt::WContainerWidget *parent);
    void setupCategoryCreationPage(Wt::WContainerWidget *parent);
    double balance = 0.0;

    Wt::WLabel *errorLabel;
    Wt::WContainerWidget *categoryContainer;
    Wt::WComboBox *categoryComboBox;
    Wt::WComboBox *yearComboBox;
    Wt::WComboBox *monthComboBox;
    Wt::WComboBox *dayComboBox;
    Wt::WLineEdit *expenseAmountInput;
    Wt::WPushButton *submitExpenseButton;
    Wt::WPushButton *deleteExpenseButton;
    Wt::WTable *expenseTable;
};

#endif // FINANCIALMANAGERAPP_H
