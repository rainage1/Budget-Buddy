#ifndef CURRENCY_CONVERSION_H
#define CURRENCY_CONVERSION_H

#include <string>

/**
 * @brief Convert an amount to CAD based on the specified currency.
 *
 * This function converts an amount to CAD (Canadian Dollar) based on the specified currency.
 *
 * @param amount The amount to be converted.
 * @param currency The currency type (e.g., CAD, USD, EUR, GBP).
 * @return The converted amount in CAD.
 */
double convertCurrency(double amount, const std::string& currency);

#endif // CURRENCY_CONVERSION_H
