#include "currency_conversion.h"
#include <iostream>
#include <map>

/**
 * @brief Convert an amount to CAD based on the specified currency.
 *
 * This function converts an amount to CAD (Canadian Dollar) based on the specified currency.
 *
 * @param amount The amount to be converted.
 * @param currency The currency type (e.g., CAD, USD, EUR, GBP).
 * @return The converted amount in CAD.
 */
double convertCurrency(double amount, const std::string &currency)
{
  double balance = amount;
  double convertedAmount = 0.0; // Declare convertedAmount here and initialize it.

  std::map<std::string, double> exchangeRates;
  exchangeRates["USD"] = 1.37; // 1 CAD to USD
  exchangeRates["EUR"] = 1.46; // 1 CAD to EUR
  exchangeRates["GBP"] = 1.69; // 1 CAD to GBP

  if (currency != "CAD")
  {
    double exchangeRate = exchangeRates[currency];
    convertedAmount = balance * exchangeRate;
  }
  else
  {
    std::cout << "Unsupported currency pair or invalid input." << std::endl;
  }

  return convertedAmount;
}
