
/**
 * Author: Group 32
 * Date: November 7, 2023
 * Description: Financial manager app that takes in user income and user expenses and displays
 * the user's balance and lists out their expenses.
 */

#include <Wt/WApplication.h>
#include <Wt/WBreak.h>
#include <Wt/WContainerWidget.h>
#include <Wt/WLineEdit.h>
#include <Wt/WPushButton.h>
#include <Wt/WText.h>
#include <vector>
#include <iomanip>
#include "FinancialManagerApp.h"
#include "add_income.h"
#include "currency_conversion.h"
#include <Wt/WDate.h>
#include <Wt/WCalendar.h>

/*
 * The env argument contains information about the new session, and
 * the initial request. It must be passed to the WApplication
 * constructor so it is typically also an argument for your custom
 * application constructor.
 */

FinancialManagerApp::FinancialManagerApp(const Wt::WEnvironment &env) : Wt::WApplication(env)
{
	setTitle("Financial Manager");
	setupApp();
}

/*
 * setupApp sets up each section with containers.
 */

void FinancialManagerApp::setupApp()
{

	Wt::WContainerWidget *mainContent = root()->addWidget(std::make_unique<Wt::WContainerWidget>());

	// Add Income Page
	setupAddIncomePage(mainContent);

	// Check Balance Page
	setupCheckBalancePage(mainContent);

	// Convert Currency Page
	setupConvertCurrencyPage(mainContent);

	// Category Creation Page
	setupCategoryCreationPage(mainContent);
}

/**
 * Category Creation page handles all of the user's expense inputs, including category selection, amounts,
 * dates and displaying expenses, along with error handling for invalid inputs for dates and expense amounts.
 */

void FinancialManagerApp::setupCategoryCreationPage(Wt::WContainerWidget *parent)
{

	/**
	 * Creates the layout and the dropdown box for the categories and dates.
	 */
	categoryContainer = root()->addWidget(std::make_unique<Wt::WContainerWidget>());
	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());
	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());

	categoryContainer->addWidget(std::make_unique<Wt::WLabel>("Expenses"));
	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());
	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());
	categoryContainer->addWidget(std::make_unique<Wt::WLabel>("Select Category: "));

	categoryComboBox = categoryContainer->addWidget(std::make_unique<Wt::WComboBox>());
	categoryComboBox->addItem("Housing");
	categoryComboBox->addItem("Utilities");
	categoryComboBox->addItem("Transportation");
	categoryComboBox->addItem("Groceries");
	categoryComboBox->addItem("Savings");
	categoryComboBox->addItem("Investments");
	categoryComboBox->addItem("Entertainment");
	categoryComboBox->addItem("Other");

	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());
	categoryContainer->addWidget(std::make_unique<Wt::WLabel>("Enter Expense Date: "));

	yearComboBox = categoryContainer->addWidget(std::make_unique<Wt::WComboBox>());
	yearComboBox->addItem("2023");
	yearComboBox->addItem("2022");
	yearComboBox->addItem("2021");
	yearComboBox->addItem("2020");
	yearComboBox->addItem("2019");
	yearComboBox->addItem("2018");
	yearComboBox->addItem("2017");
	yearComboBox->addItem("2016");
	yearComboBox->addItem("2015");
	yearComboBox->addItem("2014");
	yearComboBox->addItem("2013");

	monthComboBox = categoryContainer->addWidget(std::make_unique<Wt::WComboBox>());
	monthComboBox->addItem("January");
	monthComboBox->addItem("February");
	monthComboBox->addItem("March");
	monthComboBox->addItem("April");
	monthComboBox->addItem("May");
	monthComboBox->addItem("June");
	monthComboBox->addItem("July");
	monthComboBox->addItem("August");
	monthComboBox->addItem("September");
	monthComboBox->addItem("October");
	monthComboBox->addItem("November");
	monthComboBox->addItem("December");

	dayComboBox = categoryContainer->addWidget(std::make_unique<Wt::WComboBox>());
	dayComboBox->addItem("1");
	dayComboBox->addItem("2");
	dayComboBox->addItem("3");
	dayComboBox->addItem("4");
	dayComboBox->addItem("5");
	dayComboBox->addItem("6");
	dayComboBox->addItem("7");
	dayComboBox->addItem("8");
	dayComboBox->addItem("9");
	dayComboBox->addItem("10");
	dayComboBox->addItem("11");
	dayComboBox->addItem("12");
	dayComboBox->addItem("13");
	dayComboBox->addItem("14");
	dayComboBox->addItem("15");
	dayComboBox->addItem("16");
	dayComboBox->addItem("17");
	dayComboBox->addItem("18");
	dayComboBox->addItem("19");
	dayComboBox->addItem("20");
	dayComboBox->addItem("21");
	dayComboBox->addItem("22");
	dayComboBox->addItem("23");
	dayComboBox->addItem("24");
	dayComboBox->addItem("25");
	dayComboBox->addItem("26");
	dayComboBox->addItem("27");
	dayComboBox->addItem("28");
	dayComboBox->addItem("29");
	dayComboBox->addItem("30");
	dayComboBox->addItem("31");

	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());

	categoryContainer->addWidget(std::make_unique<Wt::WLabel>("Enter Expense Amount: "));

	expenseAmountInput = categoryContainer->addWidget(std::make_unique<Wt::WLineEdit>());

	submitExpenseButton = categoryContainer->addWidget(std::make_unique<Wt::WPushButton>("Submit Expense"));
	categoryContainer->addWidget(std::make_unique<Wt::WBreak>());
	errorLabel = categoryContainer->addWidget(std::make_unique<Wt::WLabel>(""));

	/**
	 * Creates an expense table to hold all the user inputs of their expenses and display them on the screen.
	 */

	expenseTable = categoryContainer->addWidget(std::make_unique<Wt::WTable>());
	expenseTable->setHeaderCount(1);

	expenseTable->elementAt(0, 0)->addWidget(std::make_unique<Wt::WText>("Date"));
	expenseTable->elementAt(0, 1)->addWidget(std::make_unique<Wt::WText>("Category"));
	expenseTable->elementAt(0, 2)->addWidget(std::make_unique<Wt::WText>("Amount"));
	expenseTable->elementAt(0, 3)->addWidget(std::make_unique<Wt::WText>(""));

	submitExpenseButton->clicked().connect([=]
										   {
    // Get the current date
    Wt::WDate currentDate = Wt::WDate::currentDate();

    // Gets the selected year, month, and day from the combo boxes
    int selectedYear = std::stoi(yearComboBox->currentText().toUTF8()); //Converts to an integer
    int selectedMonth = monthComboBox->currentIndex() + 1; // Adds one because the index is 0-based
    int selectedDay = std::stoi(dayComboBox->currentText().toUTF8()); //Converts to an integer

    // Create a WDate for the selected date
    Wt::WDate selectedDate(selectedYear, selectedMonth, selectedDay);

/**
 * Error handling displays an error if users input an invalid date (in the future or non existent)
*/
    if (selectedDate > currentDate) {
		errorLabel->setText("Please choose a valid date.");
    } 
	
	else if ((selectedMonth==4 || selectedMonth==6 || selectedMonth==9 || selectedMonth==11) && selectedDay>30) {
		errorLabel->setText("Please choose a valid date.");
	}

	else if (selectedMonth==2 && selectedDay>28) {
		errorLabel->setText("Please choose a valid date.");
	}

	else {
        // Date is valid, continue with adding the expense
		errorLabel->setText("");
        const Wt::WString category = categoryComboBox->currentText();
        const Wt::WString amount = expenseAmountInput->valueText();
        const Wt::WString year = yearComboBox->valueText();
        const Wt::WString month = monthComboBox->valueText();
        const Wt::WString day = dayComboBox->valueText();
        const Wt::WString date = year + L"-" + month + L"-" + day;
		double amountValue;
/**
 * Attempts to convert the amount to an integer - if not a number input, it returns an error
*/
		try {
    amountValue = std::stod(amount.toUTF8());
} catch (const std::invalid_argument& e) {
    errorLabel->setText("Please enter a valid expense amount.");
}
	
/**
 * Returns errors if the expense is greater than the user's balance, or if the expense is
 * negative, 0 or blank
*/
		if (amountValue > balance) {
			errorLabel->setText("Please enter a valid expense amount.");
		}
		else if (amountValue <= 0) {
			errorLabel->setText("Please enter a valid expense amount.");
		}
		else {
			balance -= amountValue;	
		
		
        if (!category.empty() && !amount.empty() && !date.empty()) {
            // Add the expense to the SQLite database and update the table
            int row = expenseTable->rowCount();
            expenseTable->elementAt(row, 0)->addWidget(std::make_unique<Wt::WText>(date));
            expenseTable->elementAt(row, 1)->addWidget(std::make_unique<Wt::WText>(category));
            expenseTable->elementAt(row, 2)->addWidget(std::make_unique<Wt::WText>(amount));
        }
    } } });
}
/**
 * Add income page handles all of the user's income inputs.
 */
void FinancialManagerApp::setupAddIncomePage(Wt::WContainerWidget *parent)
{
	Wt::WContainerWidget *addIncomeContent = parent->addWidget(std::make_unique<Wt::WContainerWidget>());
	*addIncomeContent->addWidget(std::make_unique<Wt::WLabel>("Income"));
	*addIncomeContent->addWidget(std::make_unique<Wt::WBreak>());
	*addIncomeContent->addWidget(std::make_unique<Wt::WBreak>());
	Wt::WText *addIncomeHint = addIncomeContent->addWidget(std::make_unique<Wt::WText>("Enter the income amount:"));
	Wt::WLineEdit *addIncomeInput = addIncomeContent->addWidget(std::make_unique<Wt::WLineEdit>());

	Wt::WPushButton *addIncomeButton = addIncomeContent->addWidget(std::make_unique<Wt::WPushButton>("Add Income"));

	addIncomeButton->clicked().connect([=]
									   {
		double income = std::stod(addIncomeInput->text().toUTF8());
		balance += income; });
}

/**
 * Check balance page handles the user checking their balance.
 */

void FinancialManagerApp::setupCheckBalancePage(Wt::WContainerWidget *parent)
{
	Wt::WContainerWidget *checkBalanceContent = parent->addWidget(std::make_unique<Wt::WContainerWidget>());

	Wt::WText *checkBalanceHint = checkBalanceContent->addWidget(std::make_unique<Wt::WText>("Click the button to check your balance"));
	Wt::WPushButton *checkBalanceButton = checkBalanceContent->addWidget(std::make_unique<Wt::WPushButton>("Check Balance"));

	*checkBalanceContent->addWidget(std::make_unique<Wt::WBreak>());

	Wt::WText *balanceDisplay = checkBalanceContent->addWidget(std::make_unique<Wt::WText>("")); // Empty text initially

	checkBalanceButton->clicked().connect([=]
										  {
    	std::ostringstream balanceText;
		balanceText << "Balance: $" << std::fixed << std::setprecision(2) << balance;
		balanceDisplay->setText(balanceText.str()); });
}

/**
 * Convert currency page handles the user converting their currency to USD, EUR or GBP.
 */

void FinancialManagerApp::setupConvertCurrencyPage(Wt::WContainerWidget *parent)
{
	Wt::WContainerWidget *convertCurrencyContent = parent->addWidget(std::make_unique<Wt::WContainerWidget>());

	Wt::WText *convertCurrencyHint = convertCurrencyContent->addWidget(std::make_unique<Wt::WText>("Enter the amount and currency to convert:"));
	Wt::WLineEdit *amountInput = convertCurrencyContent->addWidget(std::make_unique<Wt::WLineEdit>());
	Wt::WLineEdit *currencyInput = convertCurrencyContent->addWidget(std::make_unique<Wt::WLineEdit>());

	Wt::WPushButton *convertCurrencyButton = convertCurrencyContent->addWidget(std::make_unique<Wt::WPushButton>("Convert Currency"));
	Wt::WText *convertCurrencyResult = convertCurrencyContent->addWidget(std::make_unique<Wt::WText>());

	convertCurrencyButton->clicked().connect([=]
											 {
		double amount = std::stod(amountInput->text().toUTF8());
		std::string currency = currencyInput->text().toUTF8();

		if (currency == "CAD" || currency == "USD" || currency == "EUR" || currency == "GBP") {
			double convertedAmount = convertCurrency(amount, currency);

			std::ostringstream convertCurrencyResultText;
			convertCurrencyResultText << "Converted amount: $" << std::fixed << std::setprecision(2) << convertedAmount;

			convertCurrencyResult->setText(convertCurrencyResultText.str());
		} else {
			convertCurrencyResult->setText("Invalid source currency. Please enter a valid currency.");
		} });
}
